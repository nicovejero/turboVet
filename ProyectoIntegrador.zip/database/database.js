import { createConnection } from "mysql2";

const connection = createConnection({
		host: "localhost",
		user: "root",
		password: "142857",
		database: "lunes",
		port: 3306
});

connection.connect((err) => {
	if (err) throw err;
	console.log("Connected!");
});

export default connection;