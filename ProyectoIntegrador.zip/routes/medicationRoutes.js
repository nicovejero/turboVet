import { Router } from "express";
const medication = Router();
//import sql from "./database/database.js"
medication.get ("/", (req, res)=> {
	res.send("get all medications")
});

medication.get ("/:id", (req, res)=> {
	res.send("get medication by id")
});

medication.post ("/", (req, res)=> {
	res.send("create medication")
});

medication.put ("/:id", (req, res)=> {
	res.send("update medication by id")
});

medication.delete ("/:id", (req, res)=> {
	res.send("delete medication by id")
});

export default medication;