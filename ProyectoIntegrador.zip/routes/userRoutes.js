import { Router } from "express";
import connection from "../database/database.js";

const userRoutes = Router();

userRoutes.get ("/", (req, res)=> {
	res.send("get all users")
});

userRoutes.get ("/:id", (req, res)=> {
	// select * from users where user.id=id
	res.send("get user by id")
});

userRoutes.post ("/createUser", (req, res)=> {
	//const db = connection.
	console.log("body: ", req.body)
	const { name, lastName, password, email } = req.body;
	const sql = `INSERT INTO user(name, lastname, password, email) VALUES ("${name}", "${lastName}", "${password}", "${email}")`;
	connection.query(sql, (err, result) => {
		if (err) throw err
		console.log("result", result)
		res.send("create user")
	});

	
});

userRoutes.put ("t/:id", (req, res)=> {
	res.send("update user by id")
});

userRoutes.delete ("/:id", (req, res)=> {
	res.send("delete user by id")
});


export default userRoutes;