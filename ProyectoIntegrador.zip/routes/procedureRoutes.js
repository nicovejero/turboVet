import { Router } from "express";
const procedure = Router();
//import sql from "./database/database.js"
procedure.get ("/", (req, res)=> {
	res.send("get all procedures")
});

procedure.get ("/:id", (req, res)=> {
	res.send("get procedure by id")
});

procedure.post ("/", (req, res)=> {
	res.send("create procedure")
});

procedure.put ("/:id", (req, res)=> {
	res.send("update procedure by id")
});

procedure.delete ("/:id", (req, res)=> {
	res.send("delete procedure by id")
});

export default procedure;