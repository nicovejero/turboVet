import { Router } from "express";
const pet = Router();
//import sql from "./database/database.js"
pet.get ("/", (req, res)=> {
	res.send("get all pets")
});

pet.get ("/:id", (req, res)=> {
	res.send("get pet by id")
});

pet.post ("/", (req, res)=> {
	res.send("create pet")
});

pet.put ("/:id", (req, res)=> {
	res.send("update pet by id")
});

pet.delete ("/:id", (req, res)=> {
	res.send("delete pet by id")
});

export default pet;