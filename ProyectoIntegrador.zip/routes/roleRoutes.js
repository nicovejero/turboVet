import { Router } from "express";
const role = Router();
//import sql from "./database/database.js"
role.get ("/", (req, res)=> {
	res.send("get all roles")
});

role.get ("/:id", (req, res)=> {
	res.send("get role by id")
});

role.post ("/", (req, res)=> {
	res.send("create role")
});

role.put ("/:id", (req, res)=> {
	res.send("update role by id")
});

role.delete ("/:id", (req, res)=> {
	res.send("delete role by id")
});

export default role;