import Router from "express"
import postRoutes from "./postRoutes.js"
import userRoutes from "./userRoutes.js"
import petRoutes from "./petRoutes.js"
import roleRoutes from "./roleRoutes.js"
//import example from "./example.js"

const routes = Router();

routes.use("/posts", postRoutes)
routes.use("/users", userRoutes)
routes.use("/pets", petRoutes)
routes.use("/roles", roleRoutes)
//routes.use("/examples", example)

export default routes;